package com.classwork;

import java.util.HashMap;

public class Excercise13 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		HashMap<Integer, Employee> empMap = new HashMap<Integer, Employee>();
		
		Employee emp;
		Company comp = new Company(1001, "HTC", "NULL", empMap);
		try {
			emp = new Employee(101, "john", 2000.00);
			empMap.put(101, emp);
			System.out.println(empMap);
			comp.createEmployee(emp);
		} catch (DuplicateEmployeeIdException e) {
			System.out.println(e.getErrorMessage());
		}
		try {
			emp = new Employee(102, "john", 3000.00);
			comp.createEmployee(emp);
		} catch (DuplicateEmployeeIdException e) {
			System.out.println(e.getErrorMessage());
		}
		try {
			comp.readEmployee(102);
		} catch (EmployeeNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			comp.updateEmployee(102, 8000.00);
			comp.deleteEmployee(102);
		} catch (EmployeeNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
