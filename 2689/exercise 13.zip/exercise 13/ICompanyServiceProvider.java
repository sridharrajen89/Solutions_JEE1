package com.classwork;

public interface ICompanyServiceProvider {

	public boolean createEmployee(Employee empObj) throws DuplicateEmployeeIdException;
	public Employee readEmployee(int empId) throws EmployeeNotFoundException;
	public boolean updateEmployee(int empId, double salary) throws EmployeeNotFoundException;
	public boolean deleteEmployee(int empdId) throws EmployeeNotFoundException;
	
}
