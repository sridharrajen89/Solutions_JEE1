package com.classwork;

public class DuplicateEmployeeIdException extends Exception {
	private String errorMessage;

	public DuplicateEmployeeIdException(String errorMessage) {
		super();
		this.errorMessage = errorMessage;
	}

	public String getErrorMessage() {
		return errorMessage;
	}
	
}
