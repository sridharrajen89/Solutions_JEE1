package com.classwork;

import java.util.ArrayList;
import java.util.HashMap;

public class Company implements ICompanyServiceProvider {
	
	   private int companyId;
	   private String companyName;
	   private String companyEmailId;
//	   private ArrayList<Employee> empList;
	   private HashMap<Integer, Employee> empMap;
	   
	   
	
	
	public Company(int companyId, String companyName, String companyEmailId, HashMap<Integer, Employee> empMap) {
		super();
		this.companyId = companyId;
		this.companyName = companyName;
		this.companyEmailId = companyEmailId;
		this.empMap = empMap;
	}



	public Company(int companyId, String companyName, String companyEmailId) {
		super();
		this.companyId = companyId;
		this.companyName = companyName;
		this.companyEmailId = companyEmailId;
	}
	
	

	public int getCompanyId() {
		return companyId;
	}



	public void setCompanyId(int companyId) {
		this.companyId = companyId;
	}



	public String getCompanyName() {
		return companyName;
	}



	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}



	public String getCompanyEmailId() {
		return companyEmailId;
	}



	public void setCompanyEmailId(String companyEmailId) {
		this.companyEmailId = companyEmailId;
	}



	public HashMap<Integer, Employee> getEmpList() {
		return empMap;
	}


	public void setEmpList(HashMap<Integer, Employee> empList) {
		this.empMap = empMap;
	}



	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + companyId;
		return result;
	}



	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Company other = (Company) obj;
		if (companyId != other.companyId)
			return false;
		return true;
	}

	

	@Override
	public String toString() {
		return "Company [companyId=" + companyId + ", companyName=" + companyName + ", companyEmailId=" + companyEmailId
				+ ", empMap=" + empMap + "]";
	}



	@Override
	public boolean createEmployee(Employee empObj) throws DuplicateEmployeeIdException {
		// TODO Auto-generated method stub
//		System.out.println(empMap.containsKey(empObj));
		System.out.println(empMap);
		System.out.println(empMap.get(empObj.getEmpId()));
		if(empMap.get(empObj.getEmpId())!=null) {
			throw new DuplicateEmployeeIdException("Employee already exist");
		}
		else
			empMap.put(empObj.getEmpId(),empObj);
			System.out.println(empMap);
		return true;
	}

	@Override
	public Employee readEmployee(int pempId) throws EmployeeNotFoundException {
		if(empMap.get(pempId)!=null) {
			System.out.println(empMap.get(pempId));
			return empMap.get(pempId);
		}
		else {
			throw new EmployeeNotFoundException("Employee not found");
		}
		
	}

	@Override
	public boolean updateEmployee(int pempId, double psalary) throws EmployeeNotFoundException {
		if(empMap.get(pempId)!=null) {
			empMap.get(pempId).setSalary(psalary);
			System.out.println("UPdate executed");
			System.out.println(empMap.get(pempId));
			return true;
		}
		else
			throw new EmployeeNotFoundException("Employee not found");
	}

	@Override
	public boolean deleteEmployee(int pempId) throws EmployeeNotFoundException {
		if(empMap.get(pempId)!=null) {
			empMap.remove(pempId);
			System.out.println("delete executed");
			System.out.println(empMap.get(pempId));
			return true;
		}
		else
			throw new EmployeeNotFoundException("Employee not found");
	}
	
}
