package com.java.exercise;

import java.util.HashMap;

public class CompanyMapTestMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	HashMap<Integer,Employee> empHash = new HashMap<Integer,Employee>();
	try {
		Employee e1 = new Employee(100,"Tom",1000);
		empHash.put(1, e1);
		Employee e2 = new Employee(200,"Frank",1000);
		empHash.put(2, e2);
		Employee e3 = new Employee(300,"John",1000);
		empHash.put(3, e3);
		Employee e4 = new Employee(400,"Kally",1000);
		empHash.put(4, e4);
		
		System.out.println("Total employee list : " + empHash);
		
		CompanyMap cp1 = new CompanyMap(1,"HTC","abc@gmail.com",empHash);
		if(cp1.createEmployee(e1))
		{
			System.out.println("Employee created  : "  + cp1.readEmployee(100));
		}
		if(cp1.updateEmployee(100, 9000))
		{
			System.out.println("Employee Salary updated  : " + cp1.readEmployee(100));
		}
		if(cp1.deleteEmployee(100))
		{
			System.out.println("Employee deleted  : " );
		}
	}
	catch(EmployeeNotFoundException ae) {ae.printStackTrace();}
	catch(DuplicateEmployeeIDException ae) {ae.printStackTrace();}
	catch(Exception e) {e.printStackTrace();}
	finally{System.out.println("In final");
		empHash.clear();}
	}

}
