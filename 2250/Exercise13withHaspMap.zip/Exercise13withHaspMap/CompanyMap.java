package com.java.exercise;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class CompanyMap implements ICompanyServiceProvider{

	private int companyId;
	private String companyName;
	private String companyEmailId;
	private HashMap<Integer, Employee> empHash;
	
	//Overloaded Constructors
	public CompanyMap(int companyId, String companyName, String companyEmailId, HashMap<Integer,Employee> empHash) {
		super();
		this.companyId = companyId;
		this.companyName = companyName;
		this.companyEmailId = companyEmailId;
		this.empHash = empHash;
	}

	//Getter and Setter
	
	public int getCompanyId() {
		return companyId;
	}

	public void setCompanyId(int companyId) {
		this.companyId = companyId;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getCompanyEmailId() {
		return companyEmailId;
	}

	public void setCompanyEmailId(String companyEmailId) {
		this.companyEmailId = companyEmailId;
	}

	public HashMap<Integer, Employee> getEmpList() {
		return empHash;
	}

	public void setEmpList(HashMap<Integer, Employee> empList) {
		this.empHash = empHash;
	}

	//hashCode
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + companyId;
		return result;
	}

	//equals
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CompanyMap other = (CompanyMap) obj;
		if (companyId != other.companyId)
			return false;
		return true;
	}

	//toString()
	@Override
	public String toString() {
		return "Company [companyId=" + companyId + ", companyName=" + companyName + ", companyEmailId=" + companyEmailId
				+ ", empList=" + empHash + "]";
	}
	
	@Override
	public boolean createEmployee(Employee obj) throws DuplicateEmployeeIDException
	{
		for(Map.Entry<Integer,Employee> e : empHash.entrySet())
		{
			int j=e.getKey();
			j=+1;
			empHash.put(j, obj);
			return true;
		}
		throw new DuplicateEmployeeIDException();
	}
	
	@Override
	public Employee readEmployee(int empId) throws EmployeeNotFoundException
	{
		Employee obj = new Employee(); 
			for(Map.Entry<Integer,Employee> entry : empHash.entrySet())
			{
			if(entry.getValue().getEmpId()==empId)
			 obj = entry.getValue();
			return obj;
			}
		throw new EmployeeNotFoundException("Employee not found");
	}
	
	@Override
	public boolean updateEmployee(int empId,double newSalary) throws EmployeeNotFoundException
	{
		for(Map.Entry<Integer,Employee> entry : empHash.entrySet())
		{
			if(entry.getValue().getEmpId()!=empId)
				continue;
			else
			entry.getValue().setEmpSalary(newSalary);
			return true;
		}
		throw new EmployeeNotFoundException("Employee Salary cannot be update");
	}
	
	@Override
	public boolean deleteEmployee(int empId) throws EmployeeNotFoundException
	{
		boolean flag = false;
		for(Map.Entry<Integer,Employee> entry : empHash.entrySet())
		{
			if(entry.getValue().getEmpId()!=empId) {
				 continue;
			}else {
				 int j = entry.getKey();
				 empHash.remove(j);
				 flag=true;
			}
		}	
		if(flag=false){throw new EmployeeNotFoundException("Employee not deleted");}
		return flag;
	}

}
