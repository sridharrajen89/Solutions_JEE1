package com.java.exercise;

import java.util.ArrayList;

public class Company implements ICompanyServiceProvider{

	private int companyId;
	private String companyName;
	private String companyEmailId;
	private ArrayList<Employee> empList;
	
	//Overloaded Constructors
	public Company(int companyId, String companyName, String companyEmailId, ArrayList<Employee> empList) {
		super();
		this.companyId = companyId;
		this.companyName = companyName;
		this.companyEmailId = companyEmailId;
		this.empList = empList;
	}

	//Getter and Setter
	public int getCompanyId() {
		return companyId;
	}

	public void setCompanyId(int companyId) {
		this.companyId = companyId;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getCompanyEmailId() {
		return companyEmailId;
	}

	public void setCompanyEmailId(String companyEmailId) {
		this.companyEmailId = companyEmailId;
	}

	public ArrayList<Employee> getEmpList() {
		return empList;
	}

	public void setEmpList(ArrayList<Employee> empList) {
		this.empList = empList;
	}

	//hashCode
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + companyId;
		return result;
	}

	//equals
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Company other = (Company) obj;
		if (companyId != other.companyId)
			return false;
		return true;
	}

	//toString()
	@Override
	public String toString() {
		return "Company [companyId=" + companyId + ", companyName=" + companyName + ", companyEmailId=" + companyEmailId
				+ ", empList=" + empList + "]";
	}
	
	@Override
	public boolean createEmployee(Employee obj) throws DuplicateEmployeeIDException
	{
		boolean flag = false ;
		if(empList.add(obj)) {flag = true;}
		else throw new DuplicateEmployeeIDException();
		return flag;
	}
	
	@Override
	public Employee readEmployee(int empId) throws EmployeeNotFoundException
	{
		for(Employee obj : empList)
		{
			if(obj.getEmpId()==empId)
				return obj;
		}
		throw new EmployeeNotFoundException("Employee not found");
	}
	
	@Override
	public boolean updateEmployee(int empId,double newSalary) throws EmployeeNotFoundException
	{
		for(Employee obj :empList)
		{
			if(obj.getEmpId()!=empId)
				continue;
			else
			obj.setEmpSalary(newSalary);
			return true;
		}
		throw new EmployeeNotFoundException("Employee Salary cannot be update");
	}
	
	@Override
	public boolean deleteEmployee(int empId) throws EmployeeNotFoundException
	{
		for(Employee obj : empList)
		{
			if(obj.getEmpId()==empId)
				empList.remove(empId);
				return true;
		}
		throw new EmployeeNotFoundException("Employee not deleted");
	}
}
