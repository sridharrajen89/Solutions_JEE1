package com.java.exercise;

public interface ICompanyServiceProvider {
	
	public boolean createEmployee(Employee obj) throws DuplicateEmployeeIDException;
	public Employee readEmployee(int empId) throws EmployeeNotFoundException;
	public boolean updateEmployee(int empId,double newSalary) throws EmployeeNotFoundException;
	public boolean deleteEmployee(int empId) throws EmployeeNotFoundException;

}
