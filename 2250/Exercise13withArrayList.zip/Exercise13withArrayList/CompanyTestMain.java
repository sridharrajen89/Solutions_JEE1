package com.java.exercise;

import java.util.ArrayList;

public class CompanyTestMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	ArrayList<Employee> empList = new ArrayList<Employee>();
	try {
		Employee e1 = new Employee(100,"Tom",1000);
		empList.add(e1);
		Employee e2 = new Employee(200,"Tom",1000);
		empList.add(e2);
		Employee e3 = new Employee(300,"Tom",1000);
		empList.add(e3);
		Employee e4 = new Employee(400,"Tom",1000);
		empList.add(e4);
		
		System.out.println("Total employee list : " + empList);
		
		Company cp1 = new Company(1,"HTC","abc@gmail.com",empList);
		if(cp1.createEmployee(e3))
		{
			System.out.println("Employee created  : "  + cp1.readEmployee(300));
		}
		if(cp1.updateEmployee(300, 8000))
		{
			System.out.println("Employee Salary updated  : " + cp1.readEmployee(300));
		}
		if(cp1.deleteEmployee(300))
		{
			System.out.println("Employee deleted  : "  + cp1.readEmployee(300));
		}
	}
	catch(EmployeeNotFoundException ae) {ae.printStackTrace();}
	catch(DuplicateEmployeeIDException ae) {ae.printStackTrace();}
	catch(Exception e) {e.printStackTrace();}

	}

}
